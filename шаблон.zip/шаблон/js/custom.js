/*var newWnd = window.open();
newWnd.opener = null;*/