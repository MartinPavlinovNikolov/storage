# bubble-bg [(live demo)](https://bondoer.fr/demos/bubble-bg)
A tiny JavaScript animated background with canvas.

<a href="https://bondoer.fr/demos/bubble-bg/">![Screenshot](http://i.imgur.com/y0b1391.png)</a>

## Features
* 4-color gradient
* Bubbles
* Smoothly transitions
* Detects mobile devices and tries to use less resources
* Pure JavaScript, no dependencies

## License
This project is licensed under the
[Creative Commons Zero 1.0](https://creativecommons.org/publicdomain/zero/1.0/).
